source("/Users/wayne/workspace/UsagePrediction/R/AnormalyDetection.R")
source("/Users/wayne/workspace/UsagePrediction/R/DetectAnoms.R")
source("/Users/wayne/workspace/UsagePrediction/R/util.R")
source("/Users/wayne/workspace/UsagePrediction/R/comb_forecast.R")
source("/Users/wayne/workspace/UsagePrediction/R/outlier_replace.R")
source("/Users/wayne/workspace/UsagePrediction/R/prediction_method.R")
source("/Users/wayne/workspace/UsagePrediction/R/main_function.R")

geo <- 'NA'
raw_data <- read.csv(paste0('/Users/wayne/workspace/PCG service parts/data/TopmostPN_filter_weekly_consumption(change)/TopmostPN_', geo, '_weekly_consumption_filter(change).csv'), header = TRUE)
raw_data2 <- read.csv(paste0('/Users/wayne/workspace/PCG service parts/data/TopmostPN_ib_filter(change)/TopmostPN_', geo, '_ib_withdate_filter.csv'), header = FALSE)
PN <- '01AY839'
PN_usage <- raw_data[raw_data$TopmostPN==PN,]
PN_usage$Data <- as.Date(PN_usage$Data)
PN_usage$DataNum <- as.numeric(as.vector(PN_usage$DataNum))
PN_usage <- PN_usage[, c('Data', 'DataNum')]
colnames(PN_usage) <- c('Date', 'Magnitude')
PN_IB <- raw_data2[raw_data2$V1==PN,]
PN_IB$V3 <- as.Date(PN_IB$V3)
PN_IB$V4 <- as.numeric(as.vector(PN_IB$V4))
PN_IB <- PN_IB[, c('V3', 'V4')]
colnames(PN_IB) <- c('Date', 'Magnitude')
results <- main_function(PN_usage, PN_IB, interval=8, percentage=1)
results$pred_plot <- results$pred_plot + ggplot2::geom_point(data=results$pred_results, ggplot2::aes_string(x="date", y="IB"), colour = "#009E73", alpha=0.6, size = 2)
results$pred_plot <- results$pred_plot + ggplot2::geom_line(data=results$pred_results, ggplot2::aes_string(x="date", y="IB"), colour = "#56B4E9", alpha=0.6)




# l <- 78
# res1 <- Anomaly_Detection(PN_usage[1:l, ], PN_IB, alpha = 0.1)
# res1$plot <- res1$plot + ggplot2::geom_line(data=PN_usage, ggplot2::aes_string(x="Date", y="Magnitude"), alpha=0.2)
# if(!(dim(res1$anoms)[1]==0)){
#   rep_PN_usage <- replace_outlier(PN_usage[1:l, ], res1$anoms, replace_method="karman")
#   replace_data <- rep_PN_usage[(rep_PN_usage[[1]] %in% res1$anoms[[1]]), ]
#   res1$plot <- res1$plot + ggplot2::geom_point(data=replace_data, ggplot2::aes_string(x="Date", y="Magnitude"), colour = "black", size = 3, shape = 1)
#   res1$plot <- res1$plot + ggplot2::geom_point(data=rep_PN_usage, ggplot2::aes_string(x="Date", y="Magnitude"), colour = "blue", alpha=0.2)
#   pred1 <- prediction_method(rep_PN_usage, PN_IB, lag=res1$lag, message =res1$message, pred_length=26, pred_method='IB')
#   res1$plot <- res1$plot + ggplot2::geom_point(data=pred1$IB_trasfer, ggplot2::aes_string(x="timestamp", y="baseline"), alpha=0.6, size = 1)
#   res1$plot <- res1$plot + ggplot2::geom_point(data=pred1$pred, ggplot2::aes_string(x="Date", y="Magnitude"), colour = "#009E73", alpha=0.6, size = 2)
#   res1$plot <- res1$plot + ggplot2::geom_line(data=pred1$pred, ggplot2::aes_string(x="Date", y="Magnitude"), colour = "#56B4E9", alpha=0.6)
# } else {
#   rep_PN_usage <- replace_outlier(PN_usage[1:l, ], res1$anoms, replace_method="karman")
#   res1$plot <- res1$plot + ggplot2::geom_point(data=rep_PN_usage, ggplot2::aes_string(x="Date", y="Magnitude"), colour = "blue", alpha=0.2)
#   pred1 <- prediction_method(rep_PN_usage, PN_IB, lag=res1$lag, message =res1$message, pred_length=26, pred_method='IB')
#   res1$plot <- res1$plot + ggplot2::geom_point(data=pred1$IB_trasfer, ggplot2::aes_string(x="timestamp", y="baseline"), alpha=0.6, size = 1)
#   res1$plot <- res1$plot + ggplot2::geom_point(data=pred1$pred, ggplot2::aes_string(x="Date", y="Magnitude"), colour = "#009E73", alpha=0.6, size = 2)
#   res1$plot <- res1$plot + ggplot2::geom_line(data=pred1$pred, ggplot2::aes_string(x="Date", y="Magnitude"), colour = "#56B4E9", alpha=0.6)
# }
# 
# 
# interval <- 26
# range <- 16
# PN_ts <- ts(PN_usage[[2]])
# me_accuracy_list <- c()
# wa_accuracy_list <- c()
# IB_accuracy_list <- c()
# HW_accuracy_list <- c()
# sa_accuracy_list <- c()
# se_accuracy_list <- c()
# arima_accuracy_list <- c()
# nn_accuracy_list <- c()
# lag <- c()
# lag_list <- c()
# 
# for(i in 1:(length(PN_ts)-range-interval)){
#   actual <- PN_ts[(i+range):(i+interval+range-1)]
#   me_pred <-rep(mean(PN_ts[i:(i+range-1)]), interval)
#   me_accuracy <- mean(abs(pmin(actual, me_pred)/pmax(actual, me_pred)) * 100)
#   w <- 1:range
#   wa_pred <- rep(weighted.mean(PN_ts[i:(i+range-1)], w), interval)
#   wa_accuracy <- mean(abs(pmin(actual, wa_pred)/pmax(actual, wa_pred)) * 100)
#   me_accuracy_list <- c(me_accuracy_list, me_accuracy)
#   wa_accuracy_list <- c(wa_accuracy_list, wa_accuracy)
#   
#   res1 <- Anomaly_Detection(PN_usage[1:(i+range-1), ], PN_IB, alpha = 0.1)
#   rep_PN_usage <- replace_outlier(PN_usage[1:(i+range-1), ], res1$anoms, replace_method="karman")
#   lag <- c(lag, lag_caculation(rep_PN_usage, PN_IB))
#   lag_list <- c(lag_list, round(mean(lag)))
#   pred1 <- prediction_method(rep_PN_usage, PN_IB, lag=round(mean(lag)), message =res1$message, pred_length=26, pred_method='IB')
#   IB_pred <- pred1$pred[[2]][1:interval]
#   IB_accuracy <- mean(abs(pmin(actual, IB_pred)/pmax(actual, IB_pred)) * 100)
#   IB_accuracy_list <- c(IB_accuracy_list, IB_accuracy)
#   
#   pred1 <- prediction_method(rep_PN_usage, PN_IB, lag=res1$lag, message =res1$message, pred_length=interval, pred_method='holt.winter')
#   HW_pred <- pred1$pred[[2]]
#   HW_accuracy <- mean(abs(pmin(actual, HW_pred)/pmax(actual, HW_pred)) * 100)
#   HW_accuracy_list <- c(HW_accuracy_list, HW_accuracy)
#   
#   pred1 <- prediction_method(rep_PN_usage, PN_IB, lag=res1$lag, message =res1$message, pred_length=interval, pred_method='stlf.arima')
#   sa_pred <- pred1$pred[[2]]
#   sa_accuracy <- mean(abs(pmin(actual, sa_pred)/pmax(actual, sa_pred)) * 100)
#   sa_accuracy_list <- c(sa_accuracy_list, sa_accuracy)
#   
#   pred1 <- prediction_method(rep_PN_usage, PN_IB, lag=res1$lag, message =res1$message, pred_length=interval, pred_method='stlf.ets')
#   se_pred <- pred1$pred[[2]]
#   se_accuracy <- mean(abs(pmin(actual, se_pred)/pmax(actual, se_pred)) * 100)
#   se_accuracy_list <- c(se_accuracy_list, se_accuracy)
#   
#   pred1 <- prediction_method(rep_PN_usage, PN_IB, lag=res1$lag, message =res1$message, pred_length=interval, pred_method='seasonal.arima')
#   arima_pred <- pred1$pred[[2]]
#   arima_accuracy <- mean(abs(pmin(actual, arima_pred)/pmax(actual, arima_pred)) * 100)
#   arima_accuracy_list <- c(arima_accuracy_list, arima_accuracy)
#   
#   pred1 <- prediction_method(rep_PN_usage, PN_IB, lag=res1$lag, message =res1$message, pred_length=interval, pred_method='NN.NNAR')
#   nn_pred <- pred1$pred[[2]]
#   nn_accuracy <- mean(abs(pmin(actual, nn_pred)/pmax(actual, nn_pred)) * 100)
#   nn_accuracy_list <- c(nn_accuracy_list, nn_accuracy)
#   
# }
# me_accuracy_mean <- mean(me_accuracy_list, na.rm = TRUE)
# wa_accuracy_mean <- mean(wa_accuracy_list, na.rm = TRUE)
# IB_accuracy_mean <- mean(IB_accuracy_list, na.rm = TRUE)
# HW_accuracy_mean <- mean(HW_accuracy_list, na.rm = TRUE)
# sa_accuracy_mean <- mean(sa_accuracy_list, na.rm = TRUE)
# se_accuracy_mean <- mean(se_accuracy_list, na.rm = TRUE)
# arima_accuracy_mean <- mean(arima_accuracy_list, na.rm = TRUE)
# nn_accuracy_mean <- mean(nn_accuracy_list, na.rm = TRUE)
# 
# print(me_accuracy_mean)
# print(wa_accuracy_mean)
# print(IB_accuracy_mean)
# print(HW_accuracy_mean)
# print(sa_accuracy_mean)
# print(se_accuracy_mean)
# print(arima_accuracy_mean)
# print(nn_accuracy_mean)
# 
# accurary_dt <- data.frame(me=me_accuracy_list, wa=wa_accuracy_list, IB=IB_accuracy_list, HW=HW_accuracy_list
#                           , sa=sa_accuracy_list, se=se_accuracy_list, arima=arima_accuracy_list)
# accurary_dt$index <- index(accurary_dt)
# accurary_dt <- reshape2::melt(accurary_dt, id="index")
# ggplot(data=accurary_dt, aes(x=index, y=value, colour=variable)) + geom_line()
# 
# ggplot(data.frame(lag), aes(lag)) + geom_density()
# 
# 
# interval <- 26
# range <- 16
# PN_ts <- ts(PN_usage[[2]])
# accuracy_list <- c()
# lag <- c()
# com_forecasts <- c()
# for(i in 1:interval){
#   actual <- PN_ts[(i+range):(i+interval+range-1)]
#   me_pred <-rep(mean(PN_ts[i:(i+range-1)]), interval)
#   me_accuracy <- mean(abs(pmin(actual, me_pred)/pmax(actual, me_pred)) * 100)
#   w <- 1:range
#   wa_pred <- rep(weighted.mean(PN_ts[i:(i+range-1)], w), interval)
#   
#   res1 <- Anomaly_Detection(PN_usage[1:(i+range-1), ], PN_IB, alpha = 0.1)
#   rep_PN_usage <- replace_outlier(PN_usage[1:(i+range-1), ], res1$anoms, replace_method="karman")
#   lag <- c(lag, lag_caculation(rep_PN_usage, PN_IB))
#   pred1 <- prediction_method(rep_PN_usage, PN_IB, lag=round(mean(lag)), message =res1$message, pred_length=26, pred_method='IB')
#   IB_pred <- pred1$pred[[2]][1:interval]
#   
#   pred1 <- prediction_method(rep_PN_usage, PN_IB, lag=res1$lag, message =res1$message, pred_length=interval, pred_method='holt.winter')
#   HW_pred <- pred1$pred[[2]]
#   
#   pred1 <- prediction_method(rep_PN_usage, PN_IB, lag=res1$lag, message =res1$message, pred_length=interval, pred_method='stlf.arima')
#   sa_pred <- pred1$pred[[2]]
#   
#   pred1 <- prediction_method(rep_PN_usage, PN_IB, lag=res1$lag, message =res1$message, pred_length=interval, pred_method='stlf.ets')
#   se_pred <- pred1$pred[[2]]
#   
#   pred1 <- prediction_method(rep_PN_usage, PN_IB, lag=res1$lag, message =res1$message, pred_length=interval, pred_method='seasonal.arima')
#   arima_pred <- pred1$pred[[2]]
#   
#   pred1 <- prediction_method(rep_PN_usage, PN_IB, lag=res1$lag, message =res1$message, pred_length=interval, pred_method='NN.NNAR')
#   nn_pred <- pred1$pred[[2]]
#   
#   indiv_forecasts <- cbind(IB_pred[1], HW_pred[1], sa_pred[1], se_pred[1], arima_pred[1], nn_pred[1])
#   com_forecasts <- rbind(com_forecasts, indiv_forecasts)
#   
# }
# 
# ind_nam <- c("IB", "HW", "sa", "se", "arima", "nn")
# colnames(com_forecasts) <- ind_nam
# actualed <- PN_ts[(1+range):(interval+range)]
# 
# 
# for(i in (interval+1):(length(PN_ts)-range-interval)){
# 
#   actual <- PN_ts[(i+range):(i+interval+range-1)]
#   me_pred <-rep(mean(PN_ts[i:(i+range-1)]), interval)
#   w <- 1:range
#   wa_pred <- rep(weighted.mean(PN_ts[i:(i+range-1)], w), interval)
#   
#   res1 <- Anomaly_Detection(PN_usage[1:(i+range-1), ], PN_IB, alpha = 0.1)
#   rep_PN_usage <- replace_outlier(PN_usage[1:(i+range-1), ], res1$anoms, replace_method="karman")
#   lag <- c(lag, lag_caculation(rep_PN_usage, PN_IB))
#   pred1 <- prediction_method(rep_PN_usage, PN_IB, lag=round(mean(lag)), message =res1$message, pred_length=26, pred_method='IB')
#   IB_pred <- pred1$pred[[2]][1:interval]
#   
#   pred1 <- prediction_method(rep_PN_usage, PN_IB, lag=res1$lag, message =res1$message, pred_length=interval, pred_method='holt.winter')
#   HW_pred <- pred1$pred[[2]]
#   
#   pred1 <- prediction_method(rep_PN_usage, PN_IB, lag=res1$lag, message =res1$message, pred_length=interval, pred_method='stlf.arima')
#   sa_pred <- pred1$pred[[2]]
#   
#   pred1 <- prediction_method(rep_PN_usage, PN_IB, lag=res1$lag, message =res1$message, pred_length=interval, pred_method='stlf.ets')
#   se_pred <- pred1$pred[[2]]
#   
#   pred1 <- prediction_method(rep_PN_usage, PN_IB, lag=res1$lag, message =res1$message, pred_length=interval, pred_method='seasonal.arima')
#   arima_pred <- pred1$pred[[2]]
#   
#   pred1 <- prediction_method(rep_PN_usage, PN_IB, lag=res1$lag, message =res1$message, pred_length=interval, pred_method='NN.NNAR')
#   nn_pred <- pred1$pred[[2]]
#   
#   combine_f <- Forecast_comb(actualed, com_forecasts, Averaging_scheme = "cls")
#   print(combine_f$weights)
#   fhat <- cbind(IB_pred, HW_pred, sa_pred, se_pred, arima_pred, nn_pred)
#   TT <- NROW(fhat)
#   predicted <- t(combine_f$weights %*% t(fhat))
#   accuracy <- mean(abs(pmin(actual, predicted)/pmax(actual, predicted)) * 100)
#   accuracy_list <- c(accuracy_list, accuracy)
#   
#   indiv_forecasts <- cbind(IB_pred[1], HW_pred[1], sa_pred[1], se_pred[1], arima_pred[1], nn_pred[1])
#   com_forecasts <- rbind(com_forecasts, indiv_forecasts)
#   actualed <- c(actualed, actual[1])
# }
# 
# 
# accuracy_mean <- mean(accuracy_list, na.rm = TRUE)
# IB_accuracy_list <- IB_accuracy_list[27:85]
# accurary_dt <- data.frame(IB=IB_accuracy_list, combine_f=accuracy_list, HW=HW_accuracy_list)
# accurary_dt$index <- index(accurary_dt)
# accurary_dt <- reshape2::melt(accurary_dt, id="index")
# ggplot(data=accurary_dt, aes(x=index, y=value, colour=variable)) + geom_line()
